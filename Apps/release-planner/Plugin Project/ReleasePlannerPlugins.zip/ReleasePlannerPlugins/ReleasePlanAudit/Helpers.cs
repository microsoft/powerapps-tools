﻿using System;
using Microsoft.Xrm.Sdk;

namespace ReleasePlanAudit
{
    public static class AttributeCollectionExtensions
    {
        public static T GetOrDefault<T>(this AttributeCollection attributeCollection, string attributeName)
        {
            _ = attributeCollection ?? throw new ArgumentNullException($"{nameof(GetOrDefault)}: {nameof(attributeCollection)} can not be null");
            _ = attributeName ?? throw new ArgumentNullException($"{nameof(GetOrDefault)}: {nameof(attributeName)} can not be null");

            if (attributeCollection.Contains(attributeName))
            {
                return (T)attributeCollection[attributeName];
            }

            return default;
        }
    }

    public static class HelperMethods
    {
        public static string AddPublisherPrefix(string appendTo)
        {
            return string.Concat(CommonFieldNameConstants.PublisherPrefix, "_", appendTo);
        }
    }
}