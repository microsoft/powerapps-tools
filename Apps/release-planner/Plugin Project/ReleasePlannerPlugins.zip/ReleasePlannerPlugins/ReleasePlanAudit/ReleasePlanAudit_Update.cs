﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;

namespace ReleasePlanAudit
{
    public class ReleasePlanAudit_Update : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            _ = serviceProvider ?? throw new ArgumentNullException($"{nameof(Execute)}: {nameof(serviceProvider)} can not be null");

            IPluginExecutionContext executionContext = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IOrganizationServiceFactory organizationServiceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService organizationService = organizationServiceFactory.CreateOrganizationService(executionContext.UserId);

            try
            {
                Entity targetReleasePlanEntity = executionContext.InputParameters["Target"] as Entity;

                // Use wrapper class to avoid hardcoding logical names
                ReleasePlanWrapper targetReleasePlan = new ReleasePlanWrapper(targetReleasePlanEntity);

                // Get updated Release Plan entity from DB
                ColumnSet releasePlanColumns = BuildReleasePlanColumnSet();
                Entity updatedReleasePlanEntity = organizationService.Retrieve(executionContext.PrimaryEntityName, executionContext.PrimaryEntityId, releasePlanColumns);

                // Use wrapper class to avoid hardcoding logical names
                ReleasePlanWrapper updatedReleasePlan = new ReleasePlanWrapper(updatedReleasePlanEntity);

                if (updatedReleasePlan.ReleaseWave != null)
                {
                    // Get PreImage of the Release Plan entity
                    Entity preImageEntity = executionContext.PreEntityImages["PreImage"] as Entity;
                    
                    // Use wrapper class to avoid hardcoding logical names
                    ReleasePlanWrapper releasePlanPreImage = new ReleasePlanWrapper(preImageEntity);

                    // Get Release Wave entity from DB
                    Guid releaseWaveId = updatedReleasePlan.ReleaseWave.Id;
                    string releaseWaveLogicalName = HelperMethods.AddPublisherPrefix(EntityNameConstants.ReleaseWave);
                    ColumnSet releaseWaveColumns = BuildReleaseWaveColumnSet();
                    Entity releaseWaveEntity = organizationService.Retrieve(releaseWaveLogicalName, releaseWaveId, releaseWaveColumns);

                    // Use wrapper class to avoid hardcoding logical names
                    ReleaseWaveWrapper releaseWave = new ReleaseWaveWrapper(releaseWaveEntity);

                    DateTime? releaseWaveDate = releaseWave.Date;
                    DateTime? releasePlanChangeDate = updatedReleasePlan.ModifiedOn;

                    if (releaseWaveDate.HasValue && releasePlanChangeDate >= releaseWaveDate.Value)
                    {
                        DateTime? currentPreviewDate = updatedReleasePlan.PreviewDate;
                        DateTime? currentGaDate = updatedReleasePlan.GaDate;

                        DateTime? newPreviewDate = targetReleasePlan.PreviewDate;
                        bool previewDateChanged = newPreviewDate.HasValue;

                        DateTime? newGaDate = targetReleasePlan.GaDate;
                        bool gaDateChanged = newGaDate.HasValue;

                        DateTime? oldPreviewDate = releasePlanPreImage.PreviewDate;
                        DateTime? oldGaDate = releasePlanPreImage.GaDate;
                        DateTime? releaseWaveStartShipDate = releaseWave.StartShipDate;
                        DateTime? releaseWaveEndShipDate = releaseWave.EndShipDate;

                        bool includeInReleasePlanChanged = targetReleasePlan.IncludeInReleasePlan.HasValue;
                        bool? currentIncludeInReleasePlan = updatedReleasePlan.IncludeInReleasePlan;

                        if (includeInReleasePlanChanged)
                        {
                            OptionSetValue action = currentIncludeInReleasePlan == true ? ActionOptionSetConstants.AddAction : ActionOptionSetConstants.RemoveAction;
                            CreateOrUpdateHistoryRecord(targetReleasePlan, releasePlanPreImage, updatedReleasePlan, action, true, organizationService, tracingService);
                        }
                        else if (gaDateChanged && previewDateChanged)
                        {
                            bool newGaDateOutOfRange = newGaDate.HasValue && (newGaDate.Value < releaseWaveStartShipDate.Value || newGaDate.Value > releaseWaveEndShipDate.Value);
                            bool oldGaDateOutOfRange = oldGaDate.HasValue && (oldGaDate.Value < releaseWaveStartShipDate.Value || oldGaDate.Value > releaseWaveEndShipDate.Value);

                            bool newPreviewDateOutOfRange = newPreviewDate.HasValue && (newPreviewDate.Value < releaseWaveStartShipDate.Value || newPreviewDate.Value > releaseWaveEndShipDate.Value);
                            bool oldPreviewDateOutOfRange = oldPreviewDate.HasValue && (oldPreviewDate.Value < releaseWaveStartShipDate.Value || oldPreviewDate.Value > releaseWaveEndShipDate.Value);

                            if (!oldPreviewDateOutOfRange && !newPreviewDateOutOfRange && !oldGaDateOutOfRange && !newGaDateOutOfRange)
                            {
                                bool isEligible =
                                    !(oldGaDate.HasValue && currentGaDate.HasValue && oldGaDate.Value.Month == currentGaDate.Value.Month && oldGaDate.Value.Year == currentGaDate.Value.Year
                                    || oldPreviewDate.HasValue && currentPreviewDate.HasValue && oldPreviewDate.Value.Month == currentPreviewDate.Value.Month && oldPreviewDate.Value.Year == currentPreviewDate.Value.Year);

                                CreateOrUpdateHistoryRecord(targetReleasePlan, releasePlanPreImage, updatedReleasePlan, ActionOptionSetConstants.UpdateAction, isEligible, organizationService, tracingService);
                            }
                        }

                        else if (gaDateChanged)
                        {
                            bool newGaDateOutOfRange = newGaDate.HasValue && (newGaDate.Value < releaseWaveStartShipDate.Value || newGaDate.Value > releaseWaveEndShipDate.Value);
                            bool oldGaDateOutOfRange = oldGaDate.HasValue && (oldGaDate.Value < releaseWaveStartShipDate.Value || oldGaDate.Value > releaseWaveEndShipDate.Value);

                            if (!oldGaDateOutOfRange && !newGaDateOutOfRange)
                            {
                                bool isEligible = !(oldGaDate.HasValue && currentGaDate.HasValue && oldGaDate.Value.Month == currentGaDate.Value.Month && oldGaDate.Value.Year == currentGaDate.Value.Year);

                                CreateOrUpdateHistoryRecord(targetReleasePlan, releasePlanPreImage, updatedReleasePlan, ActionOptionSetConstants.UpdateAction, isEligible, organizationService, tracingService);
                            }
                        }
                        else if (previewDateChanged)
                        {
                            bool newPreviewDateOutOfRange = newPreviewDate.HasValue && (newPreviewDate.Value < releaseWaveStartShipDate.Value || newPreviewDate.Value > releaseWaveEndShipDate.Value);
                            bool oldPreviewDateOutOfRange = oldPreviewDate.HasValue && (oldPreviewDate.Value < releaseWaveStartShipDate.Value || oldPreviewDate.Value > releaseWaveEndShipDate.Value);

                            if (!oldPreviewDateOutOfRange && !newPreviewDateOutOfRange)
                            {
                                bool isEligible = !(oldPreviewDate.HasValue && currentPreviewDate.HasValue && oldPreviewDate.Value.Month == currentPreviewDate.Value.Month && oldPreviewDate.Value.Year == currentPreviewDate.Value.Year);

                                CreateOrUpdateHistoryRecord(targetReleasePlan, releasePlanPreImage, updatedReleasePlan, ActionOptionSetConstants.UpdateAction, isEligible, organizationService, tracingService);
                            }
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                tracingService.Trace($"{nameof(ReleasePlanAudit_Create)}: {ex.ToString()}");
                throw new InvalidPluginExecutionException($"Error creating or updating a history record while updating a Release Plan entity", ex);
            }
        }

        private ColumnSet BuildReleasePlanColumnSet()
        {
            return new ColumnSet(HelperMethods.AddPublisherPrefix(
                ReleasePlanFieldNameConstants.ReleaseWave),
                HelperMethods.AddPublisherPrefix(ReleasePlanFieldNameConstants.PreviewDate),
                HelperMethods.AddPublisherPrefix(ReleasePlanFieldNameConstants.GaDate),
                HelperMethods.AddPublisherPrefix(ReleasePlanFieldNameConstants.IncludeInReleasePlan),
                HelperMethods.AddPublisherPrefix(ReleasePlanFieldNameConstants.Application),
                CommonFieldNameConstants.ModifiedOn,
                CommonFieldNameConstants.ModifiedBy);
        }

        private ColumnSet BuildReleaseWaveColumnSet()
        {
            return new ColumnSet(
                HelperMethods.AddPublisherPrefix(ReleaseWaveFieldNameConstants.ReleasePlanDate),
                HelperMethods.AddPublisherPrefix(ReleaseWaveFieldNameConstants.Date),
                HelperMethods.AddPublisherPrefix(ReleaseWaveFieldNameConstants.StartShipDate),
                HelperMethods.AddPublisherPrefix(ReleaseWaveFieldNameConstants.EndShipDate));
        }

        private void CreateOrUpdateHistoryRecord(
            ReleasePlanWrapper targetReleasePlan,
            ReleasePlanWrapper releasePlanPreImage, 
            ReleasePlanWrapper updatedReleasePlan, 
            OptionSetValue action, 
            bool isElgible, 
            IOrganizationService organizationService,
            ITracingService tracingService)
        {
            var updateActionHistoryQuery = new QueryExpression
            {
                EntityName = HelperMethods.AddPublisherPrefix(EntityNameConstants.ReleasePlanHistory),
                ColumnSet = new ColumnSet(true),
                Criteria = new FilterExpression
                {
                    Conditions =
                    {
                        new ConditionExpression
                        {
                            AttributeName = HelperMethods.AddPublisherPrefix(ReleasePlanHistoryFieldNameConstants.ReleasePlan),
                            Operator = ConditionOperator.Equal,
                            Values = { updatedReleasePlan.WrappedEntity.Id }
                        },
                        new ConditionExpression
                        {
                            AttributeName = HelperMethods.AddPublisherPrefix(ReleasePlanHistoryFieldNameConstants.Application),
                            Operator = ConditionOperator.Equal,
                            Values = { updatedReleasePlan.Application.Id }
                        },
                        new ConditionExpression
                        {
                            AttributeName = HelperMethods.AddPublisherPrefix(ReleasePlanHistoryFieldNameConstants.Action),
                            Operator = ConditionOperator.Equal,
                            Values = { ActionOptionSetConstants.UpdateAction.Value }
                        },
                        new ConditionExpression
                        {
                            AttributeName = HelperMethods.AddPublisherPrefix(ReleasePlanHistoryFieldNameConstants.IsEligibleForChangeHistory),
                            Operator = ConditionOperator.Equal,
                            Values = { true }
                        },
                    },
                }
            };

            DataCollection<Entity> updateActionHistoryRecords = organizationService.RetrieveMultiple(updateActionHistoryQuery).Entities;

            bool shouldUpdate = action.Value == ActionOptionSetConstants.UpdateAction.Value && updateActionHistoryRecords.Count > 0;

            if (shouldUpdate)
            {
                // Use wrapper class to avoid hardcoding logical names
                var releasePlanHistoryRecordToUpdate = new ReleasePlanHistoryWrapper(updateActionHistoryRecords[0]);
                
                UpdateHistoryRecord(releasePlanHistoryRecordToUpdate, targetReleasePlan, releasePlanPreImage, updatedReleasePlan, organizationService, tracingService);
            }
            else
            {
                CreateHistoryRecord(targetReleasePlan, releasePlanPreImage, updatedReleasePlan, action, isElgible, organizationService, tracingService);
            }
        }

        private void UpdateHistoryRecord(
            ReleasePlanHistoryWrapper historyRecordToUpdate, 
            ReleasePlanWrapper targetReleasePlan, 
            ReleasePlanWrapper releasePlanPreImage, 
            ReleasePlanWrapper updatedReleasePlan, 
            IOrganizationService service,
            ITracingService tracingService)
        {
            if (targetReleasePlan.PreviewDate.HasValue)
            {
                historyRecordToUpdate.PreviewDateCurrent = targetReleasePlan.PreviewDate;
                
                if (releasePlanPreImage.PreviewDate.HasValue)
                {
                    historyRecordToUpdate.PreviewDateOld = releasePlanPreImage.PreviewDate;
                }
            }

            if (targetReleasePlan.GaDate.HasValue)
            {
                historyRecordToUpdate.GaDateCurrent = targetReleasePlan.GaDate;

                if (releasePlanPreImage.GaDate.HasValue)
                {
                    historyRecordToUpdate.GaDateOld = releasePlanPreImage.GaDate;
                }
            }

            historyRecordToUpdate.ChangedBy = updatedReleasePlan.ModifiedBy;

            tracingService.Trace($"Updating {historyRecordToUpdate.WrappedEntity.LogicalName} entity");
            service.Update(historyRecordToUpdate.WrappedEntity);
        }

        private void CreateHistoryRecord(
            ReleasePlanWrapper targetReleasePlan, 
            ReleasePlanWrapper releasePlanPreImage, 
            ReleasePlanWrapper updatedReleasePlan, 
            OptionSetValue action, 
            bool isElgible, 
            IOrganizationService organizationService,
            ITracingService tracingService)
        {
            // Use wrapper class to avoid hardcoding logical names
            ReleasePlanHistoryWrapper releasePlanHistory = new ReleasePlanHistoryWrapper(
                new Entity(HelperMethods.AddPublisherPrefix(EntityNameConstants.ReleasePlanHistory)));

            if (targetReleasePlan.FeatureName != null)
            {
                releasePlanHistory.FeatureNameCurrent = targetReleasePlan.FeatureName;

                if (releasePlanPreImage.FeatureName != null)
                {
                    releasePlanHistory.FeatureNameOld = releasePlanPreImage.FeatureName;
                }
            }

            if (targetReleasePlan.FeatureDetails != null)
            {
                releasePlanHistory.FeatureDetailsCurrent = targetReleasePlan.FeatureDetails;

                if (releasePlanPreImage.FeatureDetails != null)
                {
                    releasePlanHistory.FeatureDetailsOld = releasePlanPreImage.FeatureDetails;
                }
            }

            if (targetReleasePlan.Summary != null)
            {
                releasePlanHistory.SummaryCurrent = targetReleasePlan.Summary;

                if (releasePlanPreImage.Summary != null)
                {
                    releasePlanHistory.SummaryOld = releasePlanPreImage.Summary;
                }
            }

            if (targetReleasePlan.BusinessValue != null)
            {
                releasePlanHistory.BusinessValueCurrent = targetReleasePlan.BusinessValue;

                if (releasePlanPreImage.BusinessValue != null)
                {
                    releasePlanHistory.BusinessValueOld = releasePlanPreImage.BusinessValue;
                }
            }

            if (targetReleasePlan.PreviewDate.HasValue)
            {
                releasePlanHistory.PreviewDateCurrent = targetReleasePlan.PreviewDate;

                if (releasePlanPreImage.PreviewDate.HasValue)
                {
                    releasePlanHistory.PreviewDateOld = releasePlanPreImage.PreviewDate;
                }
            }

            if (targetReleasePlan.GaDate.HasValue)
            {
                releasePlanHistory.GaDateCurrent = targetReleasePlan.GaDate;

                if (releasePlanPreImage.GaDate.HasValue)
                {
                    releasePlanHistory.GaDateOld = releasePlanPreImage.GaDate;
                }
            }

            if (updatedReleasePlan.Application != null)
            {
                releasePlanHistory.Application = updatedReleasePlan.Application;
            }

            if (updatedReleasePlan.ReleaseWave != null)
            {
                releasePlanHistory.ReleaseWave = updatedReleasePlan.ReleaseWave;
            }

            releasePlanHistory.ReleasePlan = new EntityReference(updatedReleasePlan.WrappedEntity.LogicalName, updatedReleasePlan.WrappedEntity.Id);
            releasePlanHistory.ChangedBy = updatedReleasePlan.ModifiedBy;
            releasePlanHistory.Action = action;
            releasePlanHistory.IsEligibleForChangeHistory = isElgible;
            releasePlanHistory.Name = "Feature date is changed";

            tracingService.Trace($"Creating {releasePlanHistory.WrappedEntity.LogicalName} entity");
            organizationService.Create(releasePlanHistory.WrappedEntity);
        }
    }
}
