﻿using Microsoft.Xrm.Sdk;

namespace ReleasePlanAudit
{
    public static class ActionOptionSetConstants
    {
        public static OptionSetValue AddAction => new OptionSetValue(299600000);
        public static OptionSetValue UpdateAction => new OptionSetValue(299600001);
        public static OptionSetValue RemoveAction => new OptionSetValue(299600002);
    }

    public static class EntityNameConstants
    {
        public static string ReleasePlan => "releaseplan";
        public static string ReleasePlanHistory => "releasenoteshistory";
        public static string ReleaseWave => "releasewave";
    }

    public static class CommonFieldNameConstants
    {
        public static string PublisherPrefix => "msft";

        public static string CreatedOn => "createdon";

        public static string CreatedBy => "createdby";

        public static string ModifiedOn => "modifiedon";

        public static string ModifiedBy => "modifiedby";

        public static string Status => "statecode";

        public static string StatusReason => "statuscode";

        public static string Name => "name";
    }

    public static class ReleasePlanFieldNameConstants
    {
        public static string ReleaseWave => "releasewaveid";

        public static string IncludeInReleasePlan => "publishedreleasenote";

        public static string GaDate => "actualreleasedate";

        public static string PreviewDate => "estimatedreleasedate";

        public static string FeatureDetails => "details";

        public static string BusinessValue => "businessvalue";

        public static string Application => "applicationid";

        public static string Summary => "summary";
    }

    public static class ReleasePlanHistoryFieldNameConstants
    {
        public static string ReleaseWave => "releasewave";

        public static string Application => "application";

        public static string ReleasePlan => "releasenote";

        public static string ChangedBy => "changedby";

        public static string Action => "action";

        public static string IsEligibleForChangeHistory => "iseligibleforchangehistory";

        // General availability date
        public static string GaDateCurrent => "generalavailabilitydatecurrent";
        public static string GaDateOld => "generalavailabilitydateold";

        // Public preview date
        public static string PreviewDateCurrent => "publicpreviewdatecurrent";
        public static string PreviewDateOld => "publicpreviewdateold";

        // Feature name
        public static string FeatureNameCurrent => "featurenamecurrent";
        public static string FeatureNameOld => "featurenameold";

        // Feature details
        public static string FeatureDetailsCurrent => "featuredetailcurrent";
        public static string FeatureDetailsOld => "featuredetailold";

        // Business value
        public static string BusinessValueCurrent => "businessvaluecurrent";
        public static string BusinessValueOld => "businessvalueold";

        // Summary
        public static string SummaryCurrent => "summarycurrent";
        public static string SummaryOld => "summaryold";
    }

    public static class ReleaseWaveFieldNameConstants
    {
        public static string Date => "date";
        
        public static string ReleasePlanDate => "releaseplandate";
        
        public static string StartShipDate => "startshipdate";
        
        public static string EndShipDate => "endshipdate";
    }
}