﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace ReleasePlanAudit
{
    public class EntityWrapperBase
    {
        private Entity _entity;

        public EntityWrapperBase(Entity entity)
        {
            _ = entity ?? throw new ArgumentNullException($"{nameof(entity)}");

            _entity = entity;
        }

        public Entity WrappedEntity => _entity;

        public DateTime? CreatedOn => GetAttributeValue<DateTime?>(CommonFieldNameConstants.CreatedOn);

        public EntityReference CreatedBy => GetAttributeValue<EntityReference>(CommonFieldNameConstants.CreatedBy);

        public DateTime? ModifiedOn => GetAttributeValue<DateTime?>(CommonFieldNameConstants.ModifiedOn);

        public EntityReference ModifiedBy => GetAttributeValue<EntityReference>(CommonFieldNameConstants.ModifiedBy);

        public string Status => GetAttributeValue<string>(CommonFieldNameConstants.Status);

        public string StatusReason => GetAttributeValue<string>(CommonFieldNameConstants.StatusReason);

        protected T GetAttributeValue<T>(string attributeName)
        {
            return _entity.Attributes.GetOrDefault<T>(attributeName);
        }

        protected T GetCustomAttributeValue<T>(string attributeName)
        {
            string attributeLogicalName = HelperMethods.AddPublisherPrefix(attributeName);
            return GetAttributeValue<T>(attributeLogicalName);
        }

        protected void SetAttributeValue<T>(string attributeName, T value)
        {
            _entity.Attributes[attributeName] = value;
        }

        protected void SetCustomAttributeValue<T>(string attributeName, T value)
        {
            string attributeLogicalName = HelperMethods.AddPublisherPrefix(attributeName);
            SetAttributeValue(attributeLogicalName, value);
        }
    }

    public class ReleasePlanWrapper : EntityWrapperBase
    {
        public ReleasePlanWrapper(Entity entity) : base(entity) {}

        public EntityReference ReleaseWave => GetCustomAttributeValue<EntityReference>(ReleasePlanFieldNameConstants.ReleaseWave);

        public bool? IncludeInReleasePlan => GetCustomAttributeValue<bool?>(ReleasePlanFieldNameConstants.IncludeInReleasePlan);

        public DateTime? GaDate => GetCustomAttributeValue<DateTime?>(ReleasePlanFieldNameConstants.GaDate);

        public DateTime? PreviewDate => GetCustomAttributeValue<DateTime?>(ReleasePlanFieldNameConstants.PreviewDate);

        public string FeatureName => GetCustomAttributeValue<string>(CommonFieldNameConstants.Name);

        public string FeatureDetails => GetCustomAttributeValue<string>(ReleasePlanFieldNameConstants.FeatureDetails);

        public string BusinessValue => GetCustomAttributeValue<string>(ReleasePlanFieldNameConstants.BusinessValue);

        public EntityReference Application => GetCustomAttributeValue<EntityReference>(ReleasePlanFieldNameConstants.Application);

        public string Summary => GetCustomAttributeValue<string>(ReleasePlanFieldNameConstants.Summary);
    }

    public class ReleasePlanHistoryWrapper : EntityWrapperBase
    {
        public ReleasePlanHistoryWrapper(Entity entity) : base(entity) { }

        public EntityReference Application
        {
            get => GetCustomAttributeValue<EntityReference>(ReleasePlanHistoryFieldNameConstants.Application);
            set => SetCustomAttributeValue(ReleasePlanHistoryFieldNameConstants.Application, value);
        }

        public EntityReference ReleasePlan
        {
            get => GetCustomAttributeValue<EntityReference>(ReleasePlanHistoryFieldNameConstants.ReleasePlan);
            set => SetCustomAttributeValue(ReleasePlanHistoryFieldNameConstants.ReleasePlan, value);
        }

        public EntityReference ReleaseWave
        {
            get => GetCustomAttributeValue<EntityReference>(ReleasePlanHistoryFieldNameConstants.ReleaseWave);
            set => SetCustomAttributeValue(ReleasePlanHistoryFieldNameConstants.ReleaseWave, value);
        }

        public EntityReference ChangedBy
        {
            get => GetCustomAttributeValue<EntityReference>(ReleasePlanHistoryFieldNameConstants.ChangedBy);
            set => SetCustomAttributeValue(ReleasePlanHistoryFieldNameConstants.ChangedBy, value);
        }

        public string Name
        {
            get => GetCustomAttributeValue<string>(CommonFieldNameConstants.Name);
            set => SetCustomAttributeValue(CommonFieldNameConstants.Name, value);
        }

        public OptionSetValue Action
        {
            get => GetCustomAttributeValue<OptionSetValue>(ReleasePlanHistoryFieldNameConstants.Action);
            set => SetCustomAttributeValue(ReleasePlanHistoryFieldNameConstants.Action, value);
        }

        public bool? IsEligibleForChangeHistory
        {
            get => GetCustomAttributeValue<bool?>(ReleasePlanHistoryFieldNameConstants.IsEligibleForChangeHistory);
            set => SetCustomAttributeValue(ReleasePlanHistoryFieldNameConstants.IsEligibleForChangeHistory, value);
        }

        public DateTime? GaDateCurrent
        {
            get => GetCustomAttributeValue<DateTime?>(ReleasePlanHistoryFieldNameConstants.GaDateCurrent);
            set => SetCustomAttributeValue(ReleasePlanHistoryFieldNameConstants.GaDateCurrent, value);
        }

        public DateTime? GaDateOld
        {
            get => GetCustomAttributeValue<DateTime?>(ReleasePlanHistoryFieldNameConstants.GaDateOld);
            set => SetCustomAttributeValue(ReleasePlanHistoryFieldNameConstants.GaDateOld, value);
        }

        public DateTime? PreviewDateCurrent
        {
            get => GetCustomAttributeValue<DateTime?>(ReleasePlanHistoryFieldNameConstants.PreviewDateCurrent);
            set => SetCustomAttributeValue(ReleasePlanHistoryFieldNameConstants.PreviewDateCurrent, value);
        }

        public DateTime? PreviewDateOld
        {
            get => GetCustomAttributeValue<DateTime?>(ReleasePlanHistoryFieldNameConstants.PreviewDateOld);
            set => SetCustomAttributeValue(ReleasePlanHistoryFieldNameConstants.PreviewDateOld, value);
        }

        public string FeatureNameCurrent
        {
            get => GetCustomAttributeValue<string>(ReleasePlanHistoryFieldNameConstants.FeatureNameCurrent);
            set => SetCustomAttributeValue(ReleasePlanHistoryFieldNameConstants.FeatureNameCurrent, value);
        }

        public string FeatureNameOld
        {
            get => GetCustomAttributeValue<string>(ReleasePlanHistoryFieldNameConstants.FeatureNameOld);
            set => SetCustomAttributeValue(ReleasePlanHistoryFieldNameConstants.FeatureNameOld, value);
        }

        public string FeatureDetailsCurrent
        {
            get => GetCustomAttributeValue<string>(ReleasePlanHistoryFieldNameConstants.FeatureDetailsCurrent);
            set => SetCustomAttributeValue(ReleasePlanHistoryFieldNameConstants.FeatureDetailsCurrent, value);
        }

        public string FeatureDetailsOld
        {
            get => GetCustomAttributeValue<string>(ReleasePlanHistoryFieldNameConstants.FeatureDetailsOld);
            set => SetCustomAttributeValue(ReleasePlanHistoryFieldNameConstants.FeatureDetailsOld, value);
        }

        public string BusinessValueCurrent
        {
            get => GetCustomAttributeValue<string>(ReleasePlanHistoryFieldNameConstants.BusinessValueCurrent);
            set => SetCustomAttributeValue(ReleasePlanHistoryFieldNameConstants.BusinessValueCurrent, value);
        }

        public string BusinessValueOld
        {
            get => GetCustomAttributeValue<string>(ReleasePlanHistoryFieldNameConstants.BusinessValueOld);
            set => SetCustomAttributeValue(ReleasePlanHistoryFieldNameConstants.BusinessValueOld, value);
        }

        public string SummaryCurrent
        {
            get => GetCustomAttributeValue<string>(ReleasePlanHistoryFieldNameConstants.SummaryCurrent);
            set => SetCustomAttributeValue(ReleasePlanHistoryFieldNameConstants.SummaryCurrent, value);
        }

        public string SummaryOld
        {
            get => GetCustomAttributeValue<string>(ReleasePlanHistoryFieldNameConstants.SummaryOld);
            set => SetCustomAttributeValue(ReleasePlanHistoryFieldNameConstants.SummaryOld, value);
        }
    }

    public class ReleaseWaveWrapper : EntityWrapperBase
    {
        public ReleaseWaveWrapper(Entity entity) : base(entity) {}

        public DateTime? Date => GetCustomAttributeValue<DateTime?>(ReleaseWaveFieldNameConstants.Date);

        public DateTime? StartShipDate => GetCustomAttributeValue<DateTime?>(ReleaseWaveFieldNameConstants.StartShipDate);
        
        public DateTime? EndShipDate => GetCustomAttributeValue<DateTime?>(ReleaseWaveFieldNameConstants.EndShipDate);
    }
}
