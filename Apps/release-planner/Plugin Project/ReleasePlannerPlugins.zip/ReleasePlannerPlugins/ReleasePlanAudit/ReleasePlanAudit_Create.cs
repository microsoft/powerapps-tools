﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace ReleasePlanAudit
{
    public class ReleasePlanAudit_Create : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            _ = serviceProvider ?? throw new ArgumentNullException($"{nameof(serviceProvider)} can not be null");

            IPluginExecutionContext executionContext = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IOrganizationServiceFactory organizationServiceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService organizationService = organizationServiceFactory.CreateOrganizationService(executionContext.UserId);

            try
            {
                if (!executionContext.InputParameters.Contains("Target") || executionContext.InputParameters["Target"] == null)
                {
                    return;
                }

                Entity targetReleasePlanEntity = (Entity)executionContext.InputParameters["Target"];
                ReleasePlanWrapper targetReleasePlan = new ReleasePlanWrapper(targetReleasePlanEntity);

                if (targetReleasePlan.IncludeInReleasePlan == false)
                {
                    return;
                }

                // Get the Release Wave entity
                string releaseWaveLogicalName = HelperMethods.AddPublisherPrefix(EntityNameConstants.ReleaseWave);
                string dateColumnLogicalName = HelperMethods.AddPublisherPrefix(ReleaseWaveFieldNameConstants.Date);
                Entity releaseWaveEntity = organizationService.Retrieve(releaseWaveLogicalName, targetReleasePlan.ReleaseWave.Id, new ColumnSet(dateColumnLogicalName));
                
                // Use wrapper class to avoid hardcoding logical names
                ReleaseWaveWrapper releaseWave = new ReleaseWaveWrapper(releaseWaveEntity);

                if (targetReleasePlan.CreatedOn >= releaseWave.Date)
                {
                    CreateRecordInHistory(targetReleasePlan, organizationService);
                }
            }

            catch (Exception ex)
            {
                tracingService.Trace($"{nameof(ReleasePlanAudit_Create)}: {ex.ToString()}");
                throw new InvalidPluginExecutionException($"Error creating a Release Plan History record while creating a Release Plan entity", ex);
            }
        }

        public void CreateRecordInHistory(ReleasePlanWrapper releasePlan, IOrganizationService service)
        {
            _ = releasePlan ?? throw new ArgumentNullException($"{nameof(CreateRecordInHistory)}: {nameof(releasePlan)} can not be null");
            _ = service ?? throw new ArgumentNullException($"{nameof(CreateRecordInHistory)}: {nameof(service)} can not be null");

            // Use wrapper class to avoid hardcoding logical names
            string releasePlanHistoryLogicalName = HelperMethods.AddPublisherPrefix(EntityNameConstants.ReleasePlanHistory);
            ReleasePlanHistoryWrapper releasePlanHistory = new ReleasePlanHistoryWrapper(new Entity(releasePlanHistoryLogicalName));

            releasePlanHistory.Name = "Feature is added";
            releasePlanHistory.Action = ActionOptionSetConstants.AddAction;
            releasePlanHistory.IsEligibleForChangeHistory = true;

            // Copy values from required fields
            releasePlanHistory.FeatureNameCurrent = releasePlan.FeatureName;
            releasePlanHistory.FeatureDetailsCurrent = releasePlan.FeatureDetails;
            releasePlanHistory.Application = releasePlan.Application;
            releasePlanHistory.ReleaseWave = releasePlan.ReleaseWave;
            releasePlanHistory.ChangedBy = releasePlan.CreatedBy;
            releasePlanHistory.ReleasePlan = new EntityReference(releasePlan.WrappedEntity.LogicalName, releasePlan.WrappedEntity.Id);

            // Copy values from optional fields
            if (releasePlan.GaDate != null)
            {
                releasePlanHistory.GaDateCurrent = releasePlan.GaDate;
            }

            if (releasePlan.PreviewDate != null)
            {
                releasePlanHistory.PreviewDateCurrent = releasePlan.PreviewDate;
            }

            if (releasePlan.BusinessValue != null)
            {
                releasePlanHistory.BusinessValueCurrent = releasePlan.BusinessValue;
            }

            if (releasePlan.Summary != null)
            {
                releasePlanHistory.SummaryCurrent = releasePlan.Summary;
            }

            // Create the Release Plan History entity
            service.Create(releasePlanHistory.WrappedEntity);
        }
    }
}

