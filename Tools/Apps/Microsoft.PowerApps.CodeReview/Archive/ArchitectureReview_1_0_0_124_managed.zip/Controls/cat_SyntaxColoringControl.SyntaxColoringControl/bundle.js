var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./SyntaxColorer/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./SyntaxColorer/index.ts":
/*!********************************!*\
  !*** ./SyntaxColorer/index.ts ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.SyntaxColoringControl = void 0;\n\nvar SyntaxColoringControl =\n/** @class */\nfunction () {\n  function SyntaxColoringControl() {}\n\n  SyntaxColoringControl.prototype.init = function (context, notifyOutputChanged, state, container) {\n    function uuidv4() {\n      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {\n        var r = Math.random() * 16 | 0,\n            v = c == 'x' ? r : r & 0x3 | 0x8;\n        return v.toString(16);\n      });\n    }\n\n    this._GUID = uuidv4();\n    this._context = context;\n    this._container = document.createElement(\"div\");\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._refreshData = this.refreshData.bind(this);\n\n    this._container.setAttribute(\"class\", \"div-style\");\n\n    this._container.setAttribute(\"id\", this._GUID);\n\n    this._value = context.parameters.SyntaxColorerText.raw || \"\";\n    this._searchItem = context.parameters.SyntaxColorerSearch.raw || \"\";\n    this._databaseSearch = context.parameters.SyntaxColorerDataBaseSearch.raw || \"\";\n    this._databaseLists = context.parameters.SyntaxColorerDataBase.raw || \"\";\n    this._container.innerText = this._value;\n    container.appendChild(this._container);\n  };\n\n  SyntaxColoringControl.prototype.refreshData = function (evt) {\n    this._output = this._divheight;\n\n    this._notifyOutputChanged();\n  };\n\n  SyntaxColoringControl.prototype.updateView = function (context) {\n    var _a;\n\n    this._value = context.parameters.SyntaxColorerText.raw || \"\";\n    this._searchItem = context.parameters.SyntaxColorerSearch.raw || \"\";\n    this._databaseSearch = context.parameters.SyntaxColorerDataBaseSearch.raw || \"\";\n    this._databaseLists = context.parameters.SyntaxColorerDataBase.raw || \"\";\n    var initText = this._value;\n    var searchItemInText = this._searchItem;\n    var dataBaseInText = this._databaseSearch;\n    var dataBaseLists = this._databaseLists;\n    var developerFormat = Comments(initText);\n    var formatText = Explorer(developerFormat);\n    var results = Colorizer(formatText, searchItemInText, dataBaseInText);\n\n    function Comments(initText) {\n      var TableComments = [];\n      var commentsRegexp = new RegExp('\\\\/\\\\/.*$|\\\\/\\\\*[\\\\s\\\\S]*?\\\\*\\\\/', 'gm');\n      var match;\n\n      while ((match = commentsRegexp.exec(initText)) != null) {\n        TableComments.push(match[0]);\n      }\n\n      for (var i = 0; i < TableComments.length; i++) {\n        initText = initText.split(TableComments[i]).join(\"<span class='comments'>\" + TableComments[i] + \"</span>\");\n      }\n\n      return initText;\n    }\n\n    function Explorer(developerFormat) {\n      var Counter = 0;\n      var LastPosition = 0;\n      var nbParanthesis = 0;\n      var StrSetting = \"\";\n      var StrTab = \"\";\n      var CodeIndente = \"\";\n\n      while (Counter < developerFormat.length && Counter != -1) {\n        LastPosition = Counter > 0 ? Counter + 1 : 0;\n\n        var _a = NextParanthesis(developerFormat, Counter),\n            Position = _a.Position,\n            Type = _a.Type;\n\n        Counter = Position;\n\n        if (Type == \")\") {\n          StrTab = GenereTab(nbParanthesis);\n          nbParanthesis = nbParanthesis - 1;\n          StrSetting = ComaReturn(developerFormat.substring(LastPosition, Counter), StrTab);\n          CodeIndente = CodeIndente + StrSetting + \"\\n\" + GenereTab(nbParanthesis) + \")\";\n        } else if (Type == \"(\") {\n          StrTab = GenereTab(nbParanthesis);\n          nbParanthesis = nbParanthesis + 1;\n          StrSetting = ComaReturn(developerFormat.substring(LastPosition, Counter + 1), StrTab);\n          CodeIndente = CodeIndente + StrSetting + \"\\n\" + GenereTab(nbParanthesis);\n        } else {\n          break;\n        }\n      }\n\n      return CodeIndente;\n    }\n\n    function NextParanthesis(CodeToProcess, IndiceDepart) {\n      var IndexParenthesis = IndiceDepart;\n      var OpenningPosition = 0;\n      var ClosingPosition = 0;\n      OpenningPosition = CodeToProcess.indexOf(\"(\", IndexParenthesis + 1);\n      ClosingPosition = CodeToProcess.indexOf(\")\", IndexParenthesis + 1);\n\n      while (CommentaryPossition(CodeToProcess, OpenningPosition) && OpenningPosition != -1) {\n        OpenningPosition = CodeToProcess.indexOf(\"(\", OpenningPosition + 1);\n      }\n\n      while (CommentaryPossition(CodeToProcess, ClosingPosition) && ClosingPosition != -1) {\n        ClosingPosition = CodeToProcess.indexOf(\")\", ClosingPosition + 1);\n      }\n\n      if (ClosingPosition == OpenningPosition + 1) {\n        return NextParanthesis(CodeToProcess, ClosingPosition);\n      }\n      /* Si ClosingPosition supérieur à OpenningPosition OU OpenningPosition supérieur à 0 ET ClosingPosition = -1\r\n      ET OpenningPosition n'est pas = -1 alors la prochaine parenthese est ouvrante*/\n\n\n      if ((ClosingPosition > OpenningPosition || OpenningPosition > 0 && ClosingPosition == -1) && OpenningPosition != -1) {\n        return {\n          Position: OpenningPosition,\n          Type: \"(\"\n        };\n      }\n      /* Si OpenningPosition supérieur à ClosingPosition OU ClosingPosition supérieur à 0 ET OpenningPosition = -1\r\n      ET ClosingPosition n'est pas = -1 alors la prochaine parenthese est fermante*/\n      else if ((ClosingPosition < OpenningPosition || ClosingPosition > 0 && OpenningPosition == -1) && ClosingPosition != -1) {\n          return {\n            Position: ClosingPosition,\n            Type: \")\"\n          };\n        } // Sinon c'est qu'il n'y plus de parenthese \n        else {\n            return {\n              Position: -1,\n              Type: \"\"\n            };\n          }\n    }\n\n    function GenereTab(nbtab) {\n      var returntab = \"\";\n\n      for (var i = 0; i < nbtab; i++) {\n        returntab = returntab + \"\\u0009\";\n      }\n\n      return returntab;\n    } //Change la , par , retour a la ligne + nombre de tabulation tabulation\n\n\n    function ComaReturn(TextIn, TextTab) {\n      var TextReturn = TextIn.split(\",\").join(\",\\n\" + TextTab);\n      return TextReturn;\n    } // Controle code commentaire\n\n\n    function CommentaryPossition(developerFormat, Counter) {\n      var StrStart = developerFormat.substring(0, Counter);\n      var Table = StrStart.split(\"\\\"\");\n\n      if ((Table.length - 1) % 2 == 1) {\n        return true;\n      }\n\n      var Table = StrStart.split(\"'\");\n\n      if ((Table.length - 1) % 2 == 1) {\n        return true;\n      }\n\n      var StartCommentary = StrStart.indexOf(\"<span class='comments'>\");\n      var EndCommentary = StrStart.indexOf(\"</span>\");\n\n      if (EndCommentary < StartCommentary) {\n        return true;\n      }\n\n      return false;\n    } //fonction de colorisation\n\n\n    function Colorizer(ColorizedText, searchItemInText, dataBaseInText) {\n      var jsonImport = __webpack_require__(/*! ./json/SyntaxColorer.json */ \"./SyntaxColorer/json/SyntaxColorer.json\");\n\n      for (var operator in jsonImport.OperatorLists) {\n        ColorizedText = ColorizedText.split(jsonImport.OperatorLists[operator]).join(\"<span class='operator'>\" + jsonImport.OperatorLists[operator] + \"</span>\");\n      }\n\n      ;\n\n      for (var textFunction in jsonImport.FunctionLists) {\n        var rep = new RegExp(jsonImport.FunctionLists[textFunction] + \"\\\\(\", \"g\");\n        ColorizedText = ColorizedText.split(rep).join(\"<span class='function'>\" + jsonImport.FunctionLists[textFunction] + \"(</span>\");\n      }\n\n      ;\n\n      for (var Bracket in jsonImport.BracketLists) {\n        ColorizedText = ColorizedText.split(jsonImport.BracketLists[Bracket]).join(\"<span class='item'>\" + jsonImport.BracketLists[Bracket] + \"</span>\");\n      }\n\n      ;\n\n      for (var logic in jsonImport.LogicLists) {\n        ColorizedText = ColorizedText.split(jsonImport.LogicLists[logic]).join(\"<span class='logic'>\" + jsonImport.LogicLists[logic] + \"</span>\");\n      }\n\n      var dataBaseArray = dataBaseLists.split(\";\");\n\n      if (dataBaseArray.length >= 1) {\n        for (var database in dataBaseArray) {\n          if (dataBaseArray[database]) {\n            ColorizedText = ColorizedText.split(dataBaseArray[database]).join(\"<span class='dataLists'>\" + dataBaseArray[database] + \"</span>\");\n          }\n        }\n      }\n\n      if (searchItemInText.length >= 2) {\n        ColorizedText = ColorizedText.split(searchItemInText).join(\"<span class='search'>\" + searchItemInText + \"</span>\");\n      }\n\n      if (dataBaseInText.length >= 2) {\n        ColorizedText = ColorizedText.split(dataBaseInText).join(\"<span class='databaseSearch'>\" + dataBaseInText + \"</span>\");\n      }\n\n      return ColorizedText;\n    }\n\n    this._context = context;\n    this._container.innerHTML = results;\n    this._divheight = (_a = document.getElementById(this._GUID)) === null || _a === void 0 ? void 0 : _a.offsetHeight;\n\n    if (parseInt(this._output) != this._divheight) {\n      this._output = this._divheight;\n\n      this._notifyOutputChanged();\n\n      console.log(\"GUID : \" + this._GUID + \" || Height : \" + this._divheight);\n    }\n\n    ;\n  };\n\n  SyntaxColoringControl.prototype.getOutputs = function () {\n    return {\n      SyntaxColorerDivHeight: this._output\n    };\n  };\n\n  SyntaxColoringControl.prototype.destroy = function () {\n    this._container.removeEventListener(\"load\", this._refreshData);\n  };\n\n  return SyntaxColoringControl;\n}();\n\nexports.SyntaxColoringControl = SyntaxColoringControl;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SyntaxColorer/index.ts?");

/***/ }),

/***/ "./SyntaxColorer/json/SyntaxColorer.json":
/*!***********************************************!*\
  !*** ./SyntaxColorer/json/SyntaxColorer.json ***!
  \***********************************************/
/*! exports provided: FunctionLists, BracketLists, OperatorLists, LogicLists, default */
/***/ (function(module) {

eval("module.exports = JSON.parse(\"{\\\"FunctionLists\\\":[\\\"Abs\\\",\\\"Acceleration\\\",\\\"ACos\\\",\\\"ACot\\\",\\\"AddColumns\\\",\\\"And\\\",\\\"App\\\",\\\"ASin\\\",\\\"Assert\\\",\\\"As\\\",\\\"Astype\\\",\\\"ATan\\\",\\\"ATan2\\\",\\\"Average\\\",\\\"Back\\\",\\\"Calendar\\\",\\\"Char\\\",\\\"Clear\\\",\\\"ClearCollect\\\",\\\"Clock\\\",\\\"Coalesce\\\",\\\"Collect\\\",\\\"Color\\\",\\\"ColorFade\\\",\\\"ColorValue\\\",\\\"Compass\\\",\\\"Concatenate\\\",\\\"Concat\\\",\\\"Concurrent\\\",\\\"Connection\\\",\\\"Count\\\",\\\"Cos\\\",\\\"Cot\\\",\\\"CountA\\\",\\\"CountIf\\\",\\\"CountRows\\\",\\\"DataSourceInfo\\\",\\\"Date\\\",\\\"DateAdd\\\",\\\"DateDiff\\\",\\\"DateTimeValue\\\",\\\"DateValue\\\",\\\"Day\\\",\\\"Defaults\\\",\\\"Degrees\\\",\\\"Disable\\\",\\\"Distinct\\\",\\\"Download\\\",\\\"DropColumns\\\",\\\"EditForm\\\",\\\"Enable\\\",\\\"EndsWith\\\",\\\"Errors\\\",\\\"EncodeUrl\\\",\\\"exactin\\\",\\\"Exit\\\",\\\"Exp\\\",\\\"Filter\\\",\\\"Find\\\",\\\"First\\\",\\\"FirstN\\\",\\\"ForAll\\\",\\\"GroupBy\\\",\\\"GUID\\\",\\\"HashTags\\\",\\\"Hour\\\",\\\"If\\\",\\\"IfError\\\",\\\"in\\\",\\\"IsBlank\\\",\\\"IsEmpty\\\",\\\"IsMatch\\\",\\\"IsNumeric\\\",\\\"IsToday\\\",\\\"IsType\\\",\\\"JSON\\\",\\\"Language\\\",\\\"Last\\\",\\\"LastN\\\",\\\"Launch\\\",\\\"Left\\\",\\\"Len\\\",\\\"Ln\\\",\\\"LoadData\\\",\\\"Location\\\",\\\"LookUp\\\",\\\"Lower\\\",\\\"Match\\\",\\\"MatchAll\\\",\\\"Max\\\",\\\"Mid\\\",\\\"Min\\\",\\\"Minute\\\",\\\"Mod\\\",\\\"Month\\\",\\\"Navigate\\\",\\\"NewForm\\\",\\\"Not\\\",\\\"Notify\\\",\\\"Now\\\",\\\"Or\\\",\\\"Param\\\",\\\"Parent\\\",\\\"Patch\\\",\\\"Pi\\\",\\\"PlainText\\\",\\\"Power\\\",\\\"Proper\\\",\\\"Radians\\\",\\\"Rand\\\",\\\"Refresh\\\",\\\"Relate\\\",\\\"Remove\\\",\\\"RemoveIf\\\",\\\"RenameColumns\\\",\\\"Replace\\\",\\\"RequestHide\\\",\\\"Reset\\\",\\\"ResetForm\\\",\\\"Revert\\\",\\\"RGBA\\\",\\\"Right\\\",\\\"Round\\\",\\\"RoundDown\\\",\\\"RoundUp\\\",\\\"SaveData\\\",\\\"Search\\\",\\\"Second\\\",\\\"Select\\\",\\\"Self\\\",\\\"Sequence\\\",\\\"Set\\\",\\\"SetFocus\\\",\\\"SetProperty\\\",\\\"ShowColumns\\\",\\\"Shuffle\\\",\\\"Sin\\\",\\\"Sort\\\",\\\"SortByColumns\\\",\\\"Split\\\",\\\"Sqrt\\\",\\\"StartsWith\\\",\\\"StdevP\\\",\\\"Substitute\\\",\\\"SubmitForm\\\",\\\"Sum\\\",\\\"Switch\\\",\\\"Table\\\",\\\"Tan\\\",\\\"Text\\\",\\\"ThisItem\\\",\\\"ThisRecord\\\",\\\"Time\\\",\\\"TimeValue\\\",\\\"TimeZoneOffset\\\",\\\"Today\\\",\\\"Trace\\\",\\\"Trim\\\",\\\"TrimEnds\\\",\\\"Ungroup\\\",\\\"Unrelate\\\",\\\"UpdateContext\\\",\\\"UpdateIf\\\",\\\"Update\\\",\\\"Upper\\\",\\\"User\\\",\\\"Validate\\\",\\\"Value\\\",\\\"VarP\\\",\\\"ViewForm\\\",\\\"Weekday\\\",\\\"With\\\",\\\"Year\\\"],\\\"BracketLists\\\":[\\\"{\\\",\\\"(\\\",\\\"}\\\",\\\")\\\"],\\\"OperatorLists\\\":[\\\"Or\\\",\\\"And\\\",\\\"&&\\\",\\\"in\\\",\\\"+\\\",\\\"-\\\",\\\"*\\\",\\\"||\\\"],\\\"LogicLists\\\":[\\\"true\\\",\\\"false\\\"]}\");\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SyntaxColorer/json/SyntaxColorer.json?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('SyntaxColoringControl.SyntaxColoringControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SyntaxColoringControl);
} else {
	var SyntaxColoringControl = SyntaxColoringControl || {};
	SyntaxColoringControl.SyntaxColoringControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SyntaxColoringControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}