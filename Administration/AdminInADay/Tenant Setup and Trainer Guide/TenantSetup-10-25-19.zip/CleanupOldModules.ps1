﻿Uninstall-Module -name Microsoft.PowerApps.Administration.PowerShell -AllVersions
uninstall-module -name Microsoft.PowerApps.PowerShell -AllVersions
uninstall-module -name Microsoft.Xrm.OnlineManagementAPI -AllVersions
uninstall-module -name Microsoft.Xrm.Data.Powershell -AllVersions
uninstall-module -name MSOnline -AllVersions
uninstall-module -name AzureAD -AllVersions