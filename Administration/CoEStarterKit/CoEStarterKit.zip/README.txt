The documentation and setup instructions have now moved to
https://docs.microsoft.com/power-platform/guidance/coe/starter-kit